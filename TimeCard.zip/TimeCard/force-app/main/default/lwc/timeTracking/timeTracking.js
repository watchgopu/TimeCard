import { LightningElement, wire, track } from 'lwc';
import getProjects from '@salesforce/apex/TimeTrackingController.getProjects';
import saveTimeLog from '@salesforce/apex/TimeTrackingController.saveTimeLog';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class TimeTracking extends LightningElement {
    @track projects = [];
    selectedProject = '';
    hoursWorked = 0;
    logDate = new Date().toISOString().split('T')[0]; // Default to today

    // Load project options from Apex
    @wire(getProjects)
    wiredProjects({ error, data }) {
        if (data) {
            this.projects = data.map(proj => ({ label: proj.Name, value: proj.Id }));
        } else if (error) {
            this.showToast('Error', 'Failed to load projects.', 'error');
        }
    }

    handleProjectChange(event) {
        this.selectedProject = event.target.value;
    }

    handleHoursChange(event) {
        this.hoursWorked = event.target.value;
    }

    handleDateChange(event) {
        this.logDate = event.target.value;
    }

    submitTimeLog() {
        if (!this.selectedProject || this.hoursWorked <= 0 || this.hoursWorked > 8) {
            this.showToast('Validation Error', 'Please select a project and enter up to 8 hours.', 'error');
            return;
        }

        saveTimeLog({ projectId: this.selectedProject, hoursWorked: parseFloat(this.hoursWorked), logDate: this.logDate })
            .then(result => {
                this.showToast('Success', result, 'success');
                this.resetForm();
            })
            .catch(error => {
                this.showToast('Error', error.body.message, 'error');
            });
    }

    resetForm() {
        this.selectedProject = '';
        this.hoursWorked = 0;
        this.logDate = new Date().toISOString().split('T')[0];
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
